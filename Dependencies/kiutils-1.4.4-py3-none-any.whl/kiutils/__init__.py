"""Init script for kiutils

Authors:
    (C) Marvin Mager - @mvnmgrx - 2022

License identifier:
    GPL-3.0
"""

# Intentionally left blank ..